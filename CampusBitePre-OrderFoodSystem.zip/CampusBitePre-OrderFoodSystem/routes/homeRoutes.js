const express = require("express");
const router = express.Router();

const isLoggedIn = require("../middleware/authMiddleware");

// Homepage
router.get("/", (req, res) => {
  res.render("index");
});

router.get("/dashboard", (req, res) => {
  if (!req.session.user) {
    return res.redirect("/auth/login");
  }

  res.render("dashboard", {
    user: req.session.user,
  });
});

module.exports = router;