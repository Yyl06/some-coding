public class voidFunc {
    public static void printMessage() {
        System.out.println("Hello from a void function!");
    }

    public static void main(String[] args) {
        printMessage();
    }
}
