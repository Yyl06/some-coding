public class ifelse{
    public static void main(String[] args){
        int x = 10;
        int y = 5;

        if(x == y){
            System.out.println(x + "is equal to" + y);
        }else if(x > y){
            System.out.println(x + "is bigger than" + y);
        }else{
            System.out.println(x + "is smaller than" + y);
        }
    }
}
